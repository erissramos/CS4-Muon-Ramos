/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ex03_muon_ramos;

/**
 *
 * @author Eris
 */
public class Song {
    String title, genre, artist;
    double runTime;
    
    public Song(String title, String genre, String artist, double RunTime) {
        this.title = title;
        this.genre = genre;
        this.artist = artist;
        this.runTime = 0.0;
    }
       
}
