/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ex03_muon_ramos;

/**
 *
 * @author Eris
 */
public class Singer {
    String name;
    int noOfPerformance;
    double earnings;
    Song favoriteSong;
    
    public Singer(String name, int noOfPerformance, double earnings, Song favoriteSong) {
        this.name = name;
        this.noOfPerformance = 0;
        this.earnings = 0.0;   
        this.favoriteSong = favoriteSong;
    }
    
    public void performForAudience() {
        int noOfPeople = 0;
        if (noOfPeople > 0) {
            noOfPerformance++;
            earnings = earnings + 100;                    
        }
    }
    
    public void changeFavSong() {
        
    }
}
