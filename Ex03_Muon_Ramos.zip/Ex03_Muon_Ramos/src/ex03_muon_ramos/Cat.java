/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ex03_muon_ramos;

/**
 *
 * @author Eris
 */
public class Cat {
    String name, breed;
    int friendliness;
    
    public Cat(String name, String breed, int friendliness) {
        this.name = name;
        this.breed = breed;
        this.friendliness = 0; 
    }
}
