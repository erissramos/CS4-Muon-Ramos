/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ex07_muon_ramos;

/**
 *
 * @author Eris
 */
public class GrassType extends Monster{
    //Constructor
    public GrassType(String name, int hp, int base){
        super(name, "grass", "water", "fire", hp, base);
    
    atk *= base;
    def *= base;
    }
   
    //Methods
    @Override
    public void rest(){
        hp += maxHP * 0.50;
    }
    
    @Override
    public void special() {
        hp += maxHP * 0.20;
    }
}

