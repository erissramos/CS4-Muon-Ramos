/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ex07_muon_ramos;

import java.util.Scanner;

/**
 *
 * @author Eris
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    
    public static void main(String[] args) {
        System.out.println("Welcome to the world of Pokemon!");
        
        Trainer t1 = new Trainer("Eris");
        GrassType m1 = new GrassType("Budew", 200, 50);
        NPC n1 = new NPC("Erika", "My name is Erika, and I love Grass-type Pokémon.");
        Location l1 = new Location("Lumiose City", "Lumiose Galette");
        
        //trainer interacts
        System.out.println(t1.getName() + " inspects Monster, " + m1.getName() + ".");
        t1.inspect(m1);

        System.out.println(t1.getName() + " inspects NPC, " + n1.getName() + ".");
        t1.inspect(n1);

        System.out.println(t1.getName() + " inspects Location, " + l1.getName() + ".");
        t1.inspect(l1);
  }
}