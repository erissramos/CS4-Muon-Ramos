/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ex07_muon_ramos;

/**
 *
 * @author Eris
 */
public class FireType extends Monster{
    //Constructor
    public FireType(String name, int hp, int base) {
        super(name, "fire", "grass", "water", hp, base);
        
        atk *= 1.3;
        def *= 0.7;
    }
    //Methods    
    @Override
    public void special(){
        atk += 2;
        hp += (int) (maxHP * 0.10);
    }
    
}



