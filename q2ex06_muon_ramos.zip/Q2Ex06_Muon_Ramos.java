/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package q2ex06_muon_ramos;

import java.util.Scanner;

/**
 *
 * @author MUON
 */
public class Q2Ex06_Muon_Ramos {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Monster m1;
        Monster m2;
        String input;
        
        int hpAmt = 200;
        
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Hello welcome to pokemon battle!");
        System.out.println("[1] Fire Type");
        System.out.println("[2] Grass Type");
        System.out.println("[3] Water Type");
        
        System.out.println("What type is your first pokemon?");
        input = sc.nextLine();
        switch (input){
            case "1":
                m1 = new FireType("Charmander", hpAmt, 40);
                System.out.println("You chose Charmander!");
                break;
            case "2":
                m1 = new GrassType("Bulbasaur", hpAmt, 40);
                System.out.println("You chose Bulbasaur!");
                break;
            case "3":
                m1 = new WaterType("Squirtle", hpAmt, 40);
                System.out.println("You chose Squirtle!");
                break;
            default:
                System.out.println("Input error. Try Again.");
                m1 = new GrassType("Bulbasaur", hpAmt, 40);
                System.out.println("You get Bulbasaur!");
                break;
        }
        
        System.out.println("What type is your second pokemon?");
        input = sc.nextLine();
        switch (input){
            case "1":
                m2 = new FireType("Charmander", hpAmt, 40);
                System.out.println("You chose Charmander!");
                break;
            case "2":
                m2 = new GrassType("Bulbasaur", hpAmt, 40);
                System.out.println("You chose Bulbasaur!");
                break;
            case "3":
                m2 = new WaterType("Squirtle", hpAmt, 40);
                System.out.println("You chose Squirtle!");
                break;
            default:
                System.out.println("Input error. Try Again.");
                m2 = new GrassType("Bulbasaur", hpAmt, 40);
                System.out.println("You get Bulbasaur!");
                break;
        }
        
        System.out.printf("A BATTLE BETWEEN %s AND %s HAS BEGUN!\n", m1.getName(), m2.getName());
        
        boolean player1Turn = true;
        while(m1.hp > 0 && m2.hp > 0){
            System.out.printf("\n%s HP: %d", m1.getName(), m1.hp);
            System.out.printf("\n%s HP: %d\n", m2.getName(), m2.hp);
            if (player1Turn){
                System.out.println("[1] Attack");
                System.out.println("[2] Guard");
                System.out.println("[3] Charge");
                System.out.println("[4] Rest");
                System.out.println("[5] Special");
                System.out.printf("What does %s want to do?", m1.getName());
                
                input = sc.nextLine();
                
                switch (input) {
                    case "1":
                        m1.attack(m2);
                        break;
                    case"2":
                       m1.guard();
                       break;
                    case "3":
                        m1.charge();
                        break;
                    case "4":
                        m1.rest();
                        break;
                    case "5":
                        m1.special();
                        break;
                    default:
                        m1.guard();
                        break;
                }
                player1Turn = false;
            }else if (!player1Turn){
                System.out.println("[1] Attack");
                System.out.println("[2] Guard");
                System.out.println("[3] Charge");
                System.out.println("[4] Rest");
                System.out.println("[5] Special");
                System.out.printf("What does %s want to do?", m2.getName());
                
                input = sc.nextLine();
                
                switch (input) {
                    case "1":
                        m2.attack(m1);
                        break;
                    case"2":
                       m2.guard();
                       break;
                    case "3":
                        m2.charge();
                        break;
                    case "4":
                        m2.rest();
                        break;
                    case "5":
                        m2.special();
                        break;
                    default:
                        m2.guard();
                        break;
                }
                player1Turn = true;
            }
        }
        Monster m3;
        Trainer t1;
        NPC n1;
        Location l1;
        
    }
    
}
