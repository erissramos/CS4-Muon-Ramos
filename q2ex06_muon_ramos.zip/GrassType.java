/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package q2ex06_muon_ramos;

/**
 *
 * @author MUON
 */
public class GrassType extends Monster{
    //constructor
    public GrassType(String name, int hp, int base){
        super(name, "grass", "water", "fire", hp, base);
    
        atk = base;
        def = base;
    }
   
    //methods
    @Override
    public void rest(){
        hp += maxHP * 0.50;
    }
    
    @Override
    public void special() {
        System.out.println(name + " did a pose.");
        hp += maxHP * 0.20;
    }
}
