/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package q2ex06_muon_ramos;

import java.util.Scanner;

/**
 *
 * @author MUON
 */
public class Q2Ex06_Muon_Ramos {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Exercise 7: 
        Trainer t1 = null;
        Monster m3;
        NPC n1;
        Location l1;
      
    }
    
}
