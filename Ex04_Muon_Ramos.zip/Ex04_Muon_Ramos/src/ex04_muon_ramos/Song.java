/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ex04_muon_ramos;

/**
 *
 * @author Eris
 */
public class Song {
    //Fields
    public static String title, genre, artist;
    public static double runTime;
    
    public Song(String title, String genre, String artist, double RunTime) {
        this.title = title;
        this.genre = genre;
        this.artist = artist;
        this.runTime = 0.0;
    }
       
    //Getters
    public String title() {
        return title;
    }
    
    public String genre() {
        return genre;
    }
    
    public String artist() {
        return artist;
    }
    
    public double runTime() {
        return runTime;
    }
    
    //Setters
    public void setTitle(String title) {
        title = "Top of the World";
    }
    
    public void setGenre(String genre) {
        genre = "Pop";
    }
    
    public void setArtist(String artist) {
        artist = "the carpeners";
    }
    
    public void setRunTime(double runTime) {
        runTime = 3.4;
    }
}
