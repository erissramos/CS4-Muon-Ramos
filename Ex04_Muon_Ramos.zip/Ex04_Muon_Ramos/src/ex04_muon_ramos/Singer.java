/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ex04_muon_ramos;

/**
 *
 * @author Eris
 */
public class Singer {
    //Fields
    public static String name;
    public static int noOfPerformance;
    public static double earnings;
    public static Song favoriteSong;
    public static int totalPerformances = noOfPerformance;
    
    public Singer(String name, int noOfPerformance, double earnings, Song favoriteSong) {
        this.name = name;
        this.noOfPerformance = 0;
        this.earnings = 0.0;   
        this.favoriteSong = favoriteSong;
    }
    
    //Methods
    public void performForAudience(int noOfPeople, int noOfPerformance) {
        if (noOfPeople > 0) {
            noOfPerformance++;
            earnings = earnings + 100; 
        }
    } 
    
    public void performForAudience(int noOfPeople, double earnings) {
        int n = noOfPeople;
        int s = Singer;
        earnings += n*50;
        s.earnings += n*50;
    }
    
    public void changeFavSong() {
        
    }
    
    
    //Getters
    public String name() {
        name.getClass();
        return name;
    }
    
    public int noOfPerformance() {
        return noOfPerformance;
    }
    
    public double earnings() {
        return earnings;
    }
    
    public Song favoriteSong() {
        return favoriteSong;
    }
    
    //Setters
    public void setName(String name) {
        name = "Tia";
    }
    
    public void setTotalPerformances(int totalPerformances) {
        totalPerformances = noOfPerformance;
    }
    
    public void setEarnings(double earnings) {
        earnings = 100.0;
    }
    
    public void setFavoriteSong(Song favoriteSong) {
        favoriteSong = Top of the World;
    }

}
