/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ex04_muon_ramos;

/**
 *
 * @author Eris
 */
public class Cat {
    //Fields
    public static String name, breed;
    public static int friendliness;
    
    public Cat(String name, String breed, int friendliness) {
        this.name = name;
        this.breed = breed;
        this.friendliness = 0; 
    }
    
    //Getters
    public String name() {
        return name;
    }
    
    public String breed() {
        return breed;
    }
    
    public int friendliness() {
        return friendliness;
    }
    
    //Setters
    public void setName(String name) {
        name = "Jerry";
    }
    
    public void setBreed(String breed) {
        breed = "Persian";
    }
    
    public void setFriendliness(int friendliness) {
        friendliness = 4;
    }
}
