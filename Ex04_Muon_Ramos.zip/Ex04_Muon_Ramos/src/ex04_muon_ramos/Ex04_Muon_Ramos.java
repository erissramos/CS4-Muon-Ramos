/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ex04_muon_ramos;

/**
 *
 * @author Eris
 */
public class Ex04_Muon_Ramos {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Cat cat1 = new Cat("Robert", "Siamese", 1);
        Cat cat2 = new Cat("Terry", "Persian", 8);
        Cat cat3 = new Cat("Adam", "Oriental Shorthair", 4);
        
        Song song1 = new Song("Top of the World", "Pop", "The Carpenters", 3.01);
        Song song2 = new Song("Leaving on a Jet Plane", "Folk", "John Denver", 3.41);
    }
    
}
