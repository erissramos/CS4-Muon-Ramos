/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Exception.java to edit this template
 */
package exercise09muonramoseris;

/**
 *
 * @author Eris
 */
public class MonsterNotFoundException extends Exception {

    public MonsterNotFoundException() {
    }
    
    public MonsterNotFoundException(String msg) {
        super(msg);
    }
}
