/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Exception.java to edit this template
 */
package exercise09muonramoseris;

/**
 *
 * @author Eris
 */
public class FullTeamException extends Exception {
    public FullTeamException() {
    }
    
    public FullTeamException(String msg) {
        super(msg);
    }
}
